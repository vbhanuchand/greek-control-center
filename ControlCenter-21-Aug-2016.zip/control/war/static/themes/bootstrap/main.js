/*
    :copyright: Copyright 2012 Martin Pengelly-Phillips
    :license: See LICENSE.txt.
*/

define([
    'xstyle/css!./theme/dbootstrap/dbootstrap.css',
    './icon_support'
],

function (TemplatedMixin) {
    return {
        'TemplatedMixin': TemplatedMixin
    };
});

