define([], function(){
	return {
		price: 4,
		quantity: 3
	};
});