package com.services.core.config;


/*@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.services.core.controllers")
@ImportResource({"classpath:spring-controllers.xml", "classpath:spring-hibernate.xml", "classpath:spring-security.xml"})*/
public class Config /*extends WebMvcConfigurerAdapter*/ {
	
	/*
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry.addResourceHandler("/resources/**").addResourceLocations("/WEB-INF/static/");//.setCachePeriod(31556926);
	}*/
	
}